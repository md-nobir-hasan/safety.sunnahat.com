<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
        <img src="<?php if(isset($sit->image)): ?> <?php echo e(asset($site->image)); ?><?php else: ?><?php echo e(asset('assets/images/default/site-logo.png')); ?> <?php endif; ?>" alt=""
            class="brand-image img-circle elevation-3">
        <span class="brand-text font-weight-light">
            <?php if(isset($site->name)): ?> <?php echo e($site->name); ?> <?php else: ?><?php echo e('SUNNAHAT ADMIN'); ?>

            <?php endif; ?>

        </span>
    </a>

    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <?php echo $__env->make('backend.partial.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </nav>
    </div>

</aside>
<?php /**PATH /home/sunnahat/safety.sunnahat.com/resources/views/backend/partial/sidebar.blade.php ENDPATH**/ ?>